# Load packages ####
library(brms)
library(rstudioapi)
library(here)
library(dplyr)
library(ggplot2)

data<- read.csv(here("combined_data_for_analysis.csv"), header=TRUE, sep=",") # read in data
data$Year<-as.factor(data$Year)
data$ID<-as.factor(data$ID)
data$ID_trip<-as.factor(data$ID_trip)


# All variables:
fit1 <- brm(KDEareahref_95 ~ chlA+chlA1+
              SLA+SLA1+
              SST+SST1+SST2+
              windU+windU1+windU2+
              (1|ID), data = data, family = Gamma(link="log"), 
            iter = 10000, warmup = 3000,
            cores = getOption("mc.cores", 2))
summary(fit1) 

plot(fit1) 
plot(marginal_effects(fit1),points=T)

# Current year & 1-yr lags:
fit2 <- brm(KDEareahref_95 ~ chlA+chlA1+
              SLA+SLA1+
              SST+SST1+
              windU+windU1+
              (1|ID), data = data, family = Gamma(link="log"), 
            iter = 10000, warmup = 3000,
            cores = getOption("mc.cores", 2))
summary(fit2) 

plot(fit2) 
plot(marginal_effects(fit2),points=T)

# Current year & 2-yr lags:
fit3 <- brm(KDEareahref_95 ~ chlA+
              SLA+
              SST+SST2+
              windU+windU2+
              (1|ID), data = data, family = Gamma(link="log"), 
            iter = 10000, warmup = 3000,
            cores = getOption("mc.cores", 2))
summary(fit3) 

plot(fit3) 
plot(marginal_effects(fit3),points=T)

# Lags only:
fit4 <- brm(KDEareahref_95 ~ chlA1+
              SLA1+
              SST1+SST2+
              windU1+windU2+
              (1|ID), data = data, family = Gamma(link="log"), 
            iter = 10000, warmup = 3000,
            cores = getOption("mc.cores", 2))
summary(fit4) 

plot(fit4) 
plot(marginal_effects(fit4),points=T)

# 1-yr lags:
fit5 <- brm(KDEareahref_95 ~ chlA1+
              SLA1+
              SST1+
              windU1+
              (1|ID), data = data, family = Gamma(link="log"), 
            iter = 10000, warmup = 3000,
            cores = getOption("mc.cores", 2))
summary(fit5) 

plot(fit5) 
plot(marginal_effects(fit5),points=T)

# 2-yr lags:
fit6 <- brm(KDEareahref_95 ~ SST2+
              windU2+
              (1|ID), data = data, family = Gamma(link="log"), 
            iter = 10000, warmup = 3000,
            cores = getOption("mc.cores", 2))
summary(fit6) 

plot(fit6) 
plot(marginal_effects(fit6),points=T)


fit7 <- brm(KDEareahref_95 ~
              (1|ID), data = data, family = Gamma(link="log"),
            iter = 10000, warmup = 3000,
            cores = getOption("mc.cores", 2))
summary(fit7)

plot(fit7)
plot(marginal_effects(fit7),points=T)
plot(conditional_effects(fit7, effects = ""))


fixed <- as_tibble(fixef(fit5))
random <- as_tibble(ranef(fit5)$ID)
coefs <- as_tibble(coef(fit5)$ID)

# Null:
fit0 <- brm(KDEareahref_95 ~ 0+
              (1|ID), data = data, family = Gamma(link="log"), 
            iter = 10000, warmup = 3000,
            cores = getOption("mc.cores", 2))

# Model selection
fit0 <- add_criterion(fit0, "loo")
fit1 <- add_criterion(fit1, "loo")
fit2 <- add_criterion(fit2, "loo")
fit3 <- add_criterion(fit3, "loo")
fit4 <- add_criterion(fit4, "loo")
fit5 <- add_criterion(fit5, "loo")
fit6 <- add_criterion(fit6, "loo")
fit7 <- add_criterion(fit7, "loo")

loocomp <- as_tibble(loo_compare(fit0, fit1, fit2, fit3, fit4, fit5, fit6,
                                 criterion = "loo"))

looweight_stack <- as.table(loo_model_weights(fit0, fit1, fit2, fit3, fit4, fit5, fit6))
looweight_pBMA <- as.table(loo_model_weights(fit0, fit1, fit2, fit3, fit4, fit5, fit6,
                                             method = "pseudobma"))
looweights <- rbind(looweight_stack, looweight_pBMA)

loocomp
looweights

# elpd_loo is the Bayesian LOO estimate of the expected log 
# pointwise predictive density and is a sum of N individual 
# pointwise log predictive densities.

# se_elpd - This standard error is a coarse description of 
# our uncertainty about the predictive performance for unknown 
# future data.
write.csv(loocomp, file = "LOO_compare_KDEarea_local.csv")
write.csv(looweights, file = "LOO_modelweights_KDEarea_local.csv")
write.csv(fixed, file = "fit5_fixed_effects_KDEarea_local.csv")
write.csv(random, file = "fit5_random_effects_KDEarea_local.csv")
write.csv(coefs, file = "fit5_combined_coefs_KDEarea_local.csv")
