# Load packages
library(circglmbayes)
library(bpnreg)
library(here)

# Import data file 
data <- read.csv(here('combined_data_for_analysis.csv'))

# Set as factors
data$Year<-as.factor(data$Year)
data$ID<-as.factor(data$ID)


# Mean bearing ----
# Aggregate for ID 
datID <- aggregate(data, 
                   by = list(data$ID),
                   FUN = mean)

# Maximal model 
mcglm_full_maximal<-circGLM(mean_bearing_single~
                              IOD+IOD1+IOD2+
                              SAM+SAM1+SAM2+
                              SOI+SOI1+SOI2, data=datID, Q = 10000) 

plot(mcglm_full_maximal, type = "tracestack")

# Without lag 2
mcglm_full_currentlag1<-circGLM(mean_bearing_single~
                                  IOD+IOD1+
                                  SAM+SAM1+
                                  SOI+SOI1, data=datID, Q = 10000) 
plot(mcglm_full_currentlag1, type = "tracestack")

# Without lag 1
mcglm_full_currentlag2<-circGLM(mean_bearing_single~
                                  IOD+IOD2+
                                  SAM+SAM2+
                                  SOI+SOI2, data=datID, Q = 10000) 
plot(mcglm_full_currentlag2, type = "tracestack")

# Without lags
mcglm_full_current<-circGLM(mean_bearing_single~
                              IOD+
                              SAM+
                              SOI, data=datID, Q = 10000) 
plot(mcglm_full_current, type = "tracestack")

# Only lags
mcglm_full_lags<-circGLM(mean_bearing_single~
                           IOD1+IOD2+
                           SAM1+SAM2+
                           SOI1+SOI2, data=datID, Q = 10000) 
plot(mcglm_full_lags, type = "tracestack")

# 1-yr lags
mcglm_full_lag1<-circGLM(mean_bearing_single~
                           IOD1+
                           SAM1+
                           SOI1, data=datID, Q = 10000) 
plot(mcglm_full_lag1, type = "tracestack")

# 2-yr lags
mcglm_full_lag2<-circGLM(mean_bearing_single~
                           IOD2+
                           SAM2+
                           SOI2, data=datID, Q = 10000) 
plot(mcglm_full_lag2, type = "tracestack")

# Null
mcglm_full_null<-circGLM(mean_bearing_single~1, 
                         data=datID, Q = 10000) 
plot(mcglm_full_null, type = "tracestack")


# Model comparison ----
IC_compare.circGLM(mcglm_full_null, mcglm_full_maximal, mcglm_full_current, mcglm_full_currentlag1,
                   mcglm_full_currentlag2, mcglm_full_lags, mcglm_full_lag1, mcglm_full_lag2,
                   ICs = c("n_par", "lppd", "AIC_Bayes", "DIC", "DIC_alt", "WAIC1", "WAIC2"))


# Reduced models ----
mcglm_full_r1<-circGLM(mean_bearing_single~
                         SOI1, data=datID, Q = 10000) 
plot(mcglm_full_r1, type = "tracestack")

mcglm_full_r2<-circGLM(mean_bearing_single~IOD1+
                         SOI1, data=datID, Q = 10000) 
plot(mcglm_full_r2, type = "tracestack")

# Model comparison ----
IC_compare.circGLM(mcglm_full_null, mcglm_full_maximal, mcglm_full_current, mcglm_full_currentlag1,
                   mcglm_full_currentlag2, mcglm_full_lags, mcglm_full_lag1, mcglm_full_lag2,
                   mcglm_full_r1, mcglm_full_r2,
                   ICs = c("n_par", "lppd", "AIC_Bayes", "DIC", "DIC_alt", "WAIC1", "WAIC2"))


# Interpretation results ----
# Best 'full' model 
BF.circGLM(mcglm_full_lag1)$PMP_Beta_Eq
mcglm_full_lag1

# Best model overall 
BF.circGLM(mcglm_full_r2)$PMP_Beta_Eq
mcglm_full_r2