# Load packages ####
library(brms)
library(rstudioapi)
library(here)
library(dplyr)
library(ggplot2)

data<- read.csv(here("combined_data_for_analysis.csv"), header=TRUE, sep=",") # read in data
data$Year<-as.factor(data$Year)
data$ID<-as.factor(data$ID)
data$ID_trip<-as.factor(data$ID_trip)


# All variables:
fit1 <- brm(total_distance_travelled_km ~ IOD+IOD1+IOD2+
              SAM+SAM1+SAM2+
              SOI+SOI1+SOI2+
              (1|ID), data = data, family = Gamma(link="log"), 
            iter = 10000, warmup = 3000,
            cores = getOption("mc.cores", 2))
summary(fit1) 

plot(fit1) 
plot(marginal_effects(fit1),points=T)
plot(conditional_effects(fit1, effects = "SOI1"))

# Current year & 1-yr lags:
fit2 <- brm(total_distance_travelled_km ~ IOD+IOD1+
              SAM+SAM1+
              SOI+SOI1+
              (1|ID), data = data, family = Gamma(link="log"), 
            iter = 10000, warmup = 3000,
            cores = getOption("mc.cores", 2))
summary(fit2) 

plot(fit2) 
plot(marginal_effects(fit2),points=T)
plot(conditional_effects(fit2, effects = "SOI1"))

# Current year & 2-yr lags:
fit3 <- brm(total_distance_travelled_km ~ IOD+IOD2+
              SAM+SAM2+
              SOI+SOI2+
              (1|ID), data = data, family = Gamma(link="log"), 
            iter = 10000, warmup = 3000,
            cores = getOption("mc.cores", 2))
summary(fit3) 

plot(fit3) 
plot(marginal_effects(fit3),points=T)
plot(conditional_effects(fit3, effects = "SOI1"))

# Lags only:
fit4 <- brm(total_distance_travelled_km ~ IOD1+IOD2+
              SAM1+SAM2+
              SOI1+SOI2+
              (1|ID), data = data, family = Gamma(link="log"), 
            iter = 10000, warmup = 3000,
            cores = getOption("mc.cores", 2))
summary(fit4) 

plot(fit4) 
plot(marginal_effects(fit4),points=T)
plot(conditional_effects(fit4, effects = "SOI1"))

# 1-yr lags:
fit5 <- brm(total_distance_travelled_km ~ IOD1+
              SAM1+
              SOI1+
              (1|ID), data = data, family = Gamma(link="log"), 
            iter = 10000, warmup = 3000,
            cores = getOption("mc.cores", 2))
summary(fit5) 

plot(fit5) 
plot(marginal_effects(fit5),points=T)
plot(conditional_effects(fit5, effects = "SOI1"))

# 2-yr lags:
fit6 <- brm(total_distance_travelled_km ~ IOD2+
              SAM2+
              SOI2+
              (1|ID), data = data, family = Gamma(link="log"), 
            iter = 10000, warmup = 3000,
            cores = getOption("mc.cores", 2))
summary(fit6) 

plot(fit6) 
plot(marginal_effects(fit6),points=T)
plot(conditional_effects(fit6, effects = "SOI1"))

# 1-yr lagged SOI &  1-yr lagged IOD:
fit7 <- brm(total_distance_travelled_km ~ SOI1+IOD1+
              (1|ID), data = data, family = Gamma(link="log"), 
            iter = 10000, warmup = 3000,
            cores = getOption("mc.cores", 2))
summary(fit7) 

plot(fit7) 
plot(marginal_effects(fit7),points=T)
plot(conditional_effects(fit7, effects = "SOI1"))
plot(conditional_effects(fit7, effects = "IOD1"))

c_eff <- conditional_effects(fit7, effects = "SOI1")
plot(c_eff, plot = FALSE)[[1]] +
  theme_classic() + 
  ylim(0,700) + 
  ylab("Total distance travelled (km)") +
  xlab("1-yr lagged SOI")

ggsave("brms_conditional_distance_SOI1.pdf", width = 8,
       height = 6,
       units = c("cm"),
       dpi = 300)

c_eff <- conditional_effects(fit7, effects = "IOD1")
plot(c_eff, plot = FALSE)[[1]] +
  theme_classic() + 
  ylim(0,700) + 
  ylab("Total distance travelled (km)") +
  xlab("1-yr lagged IOD")

ggsave("brms_conditional_distance_IOD1.pdf", width = 8,
       height = 6,
       units = c("cm"),
       dpi = 300)


fixed <- as_tibble(fixef(fit7))
random <- as_tibble(ranef(fit7)$ID)
coefs <- as_tibble(coef(fit7)$ID)


# Null:
fit0 <- brm(total_distance_travelled_km ~ 0+
              (1|ID), data = data, family = Gamma(link="log"), 
            iter = 10000, warmup = 3000,
            cores = getOption("mc.cores", 2))

# Model selection
fit0 <- add_criterion(fit0, "loo")
fit1 <- add_criterion(fit1, "loo")
fit2 <- add_criterion(fit2, "loo")
fit3 <- add_criterion(fit3, "loo")
fit4 <- add_criterion(fit4, "loo")
fit5 <- add_criterion(fit5, "loo")
fit6 <- add_criterion(fit6, "loo")
fit7 <- add_criterion(fit7, "loo")

loocomp <- as_tibble(loo_compare(fit0, fit1, fit2, fit3, fit4, fit5, fit6, fit7,
                                 criterion = "loo"))
looweight_stack <- as.table(loo_model_weights(fit0, fit1, fit2, fit3, fit4, fit5, fit6, fit7))
looweight_pBMA <- as.table(loo_model_weights(fit0, fit1, fit2, fit3, fit4, fit5, fit6, fit7,
                                             method = "pseudobma"))
looweights <- rbind(looweight_stack, looweight_pBMA)

loocomp
looweights

# elpd_loo is the Bayesian LOO estimate of the expected log 
# pointwise predictive density and is a sum of N individual 
# pointwise log predictive densities.

# se_elpd - This standard error is a coarse description of 
# our uncertainty about the predictive performance for unknown 
# future data.
write.csv(loocomp, file = "LOO_compare_distance.csv")
write.csv(looweights, file = "LOO_modelweights_distance.csv")
write.csv(fixed, file = "fit7_fixed_effects_distance.csv")
write.csv(random, file = "fit7_random_effects_distance.csv")
write.csv(coefs, file = "fit7_combined_coefs_distance.csv")
