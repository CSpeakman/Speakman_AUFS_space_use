# Load packages
library(circglmbayes)
library(bpnreg)
library(here)

# Import data file 
data <- read.csv(here('combined_data_for_analysis.csv'))

# Set as factors
data$Year<-as.factor(data$Year)
data$ID<-as.factor(data$ID)


# Mean bearing ----
# Aggregate for ID 
datID <- aggregate(data, 
                   by = list(data$ID),
                   FUN = mean)

# Maximal model 
mcglm_full_maximal<-circGLM(mean_bearing_single~
                              chlA+chlA1+
                              SLA+SLA1+
                              SST+SST1+SST2+
                              windU+windU1+windU2, data=datID, Q = 10000) #, thin = 10
plot(mcglm_full_maximal, type = "tracestack")

# Without lag 2
mcglm_full_currentlag1<-circGLM(mean_bearing_single~
                                  chlA+chlA1+
                                  SLA+SLA1+
                                  SST+SST1+
                                  windU+windU1, data=datID, Q = 10000) #, thin = 10
plot(mcglm_full_currentlag1, type = "tracestack")

# Without lag 1
mcglm_full_currentlag2<-circGLM(mean_bearing_single~
                                  chlA+
                                  SLA+
                                  SST+SST2+
                                  windU+windU2, data=datID, Q = 10000) #, thin = 10
plot(mcglm_full_currentlag2, type = "tracestack")

# Without lags
mcglm_full_current<-circGLM(mean_bearing_single~
                              chlA+
                              SLA+
                              SST+
                              windU, data=datID, Q = 10000) #, thin = 10
plot(mcglm_full_current, type = "tracestack")

# Only lags
mcglm_full_lags<-circGLM(mean_bearing_single~
                           chlA1+
                           SLA1+
                           SST1+SST2+
                           windU1+windU2, data=datID, Q = 10000) #, thin = 10
plot(mcglm_full_lags, type = "tracestack")

# 1-yr lags
mcglm_full_lag1<-circGLM(mean_bearing_single~
                           chlA1+
                           SLA1+
                           SST1+
                           windU1, data=datID, Q = 10000) #, thin = 10
plot(mcglm_full_lag1, type = "tracestack")

# 2-yr lags
mcglm_full_lag2<-circGLM(mean_bearing_single~
                           SST2+windU2, data=datID, Q = 10000) #, thin = 10
plot(mcglm_full_lag2, type = "tracestack")

# Null
mcglm_full_null<-circGLM(mean_bearing_single~1, 
                         data=datID, Q = 10000) #, thin = 10
plot(mcglm_full_null, type = "tracestack")


# Model comparison ----
IC_compare.circGLM(mcglm_full_null, mcglm_full_maximal, mcglm_full_current, mcglm_full_currentlag1,
                   mcglm_full_currentlag2, mcglm_full_lags, mcglm_full_lag1, mcglm_full_lag2,
                   ICs = c("n_par", "lppd", "AIC_Bayes", "DIC", "DIC_alt", "WAIC1", "WAIC2"))


# Interpretation results ----
# Null model is best